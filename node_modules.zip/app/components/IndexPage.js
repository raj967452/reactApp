import React from 'react';
import App from './App';
import sample from '../sample-data';


import createReactClass from 'create-react-class';


const IndexPage = createReactClass({
    render
})